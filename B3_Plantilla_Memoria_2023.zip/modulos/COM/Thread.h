#ifndef __Thread_H
#define __Thread_H

#include "stm32f4xx_hal.h"    //Para manejar el HAL
#include "cmsis_os2.h"
#include "com.h"


int init_Th_Thread(void);



#endif
